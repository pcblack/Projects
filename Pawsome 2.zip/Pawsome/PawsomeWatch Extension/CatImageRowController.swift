import WatchKit

class CatImageRowController: NSObject {
  
  @IBOutlet weak var catImage: WKInterfaceImage!

}
