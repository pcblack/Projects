

import UIKit

class CatPhotoCell: UICollectionViewCell {
  
  @IBOutlet weak var imageView: UIImageView!
  
}
