//
//  ViewController.swift
//  AlmoralibraryAssignment
//
//  Created by Vaibhav Dutt on 2020-08-23.
//  Copyright © 2020 Vaibhav Dutt. All rights reserved.
//

import UIKit
import Alamofire
import CLHelper
import SwiftyJSON
import WatchConnectivity
class ViewController: UIViewController, WCSessionDelegate {
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    
    func sessionDidBecomeInactive(_ session: WCSession) {
        
    }
    
    func sessionDidDeactivate(_ session: WCSession) {
        
    }
    
    var city : String!
    var long : String!
    var lat : String!
    var longd : Double!
    var latd : Double!

    @IBOutlet weak var search: UITextField!
    
    @IBOutlet weak var sunSet: UILabel!
    @IBOutlet weak var sunRise: UILabel!
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("checking to see if wc session is supported")
                     
                     // Check if your IOS version can talk to the phone
                      // Does your iPhone support "talking to a watch"?
                     // If yes, then create the session
                     // If no, then output error message
                     if (WCSession.isSupported()) {
                         print("PHONE: Phone supports WatchConnectivity!")
                         let session = WCSession.default
                         session.delegate = self
                         session.activate()
                     }
                     else {
                         print("PHONE: Phone does not support WatchConnectivity")
                     }
        
    }


    @IBAction func result(_ sender: Any) {
        city = search.text
        
        CLHelper.shared.getCoordinate(fromAddress: city) { (coordinate, error) in

                guard error == nil else {

                    print(error!.localizedText)
                    return
                }

                // Get Coordinate
                print(coordinate?.latitude)
                print(coordinate?.longitude)
            
            self.latd = coordinate?.latitude
            self.longd = coordinate?.longitude
            self.lat = String(self.latd)
            self.long = String(self.longd)
            
            let URL = "https://api.sunrise-sunset.org/json?lat="+self.lat+"&lng="+self.long+"&date=today"
                 
            print(URL)
            
                   Alamofire.request(URL).responseJSON {
                       // 1. store the data from the internet in the
                       // response variable
                       response in
                       
                       // 2. get the data out of the variable
                       guard let apiData = response.result.value else {
                           print("Error getting data from the URL")
                           return
                       }
                   
                       // OUTPUT the json response to the terminal
                       print(apiData)
                       
                       
                       // GET something out of the JSON response
                       let jsonResponse = JSON(apiData)
                    
                    let sunriseTime = jsonResponse["results"]["sunrise"].string
                    let sunsetTime = jsonResponse["results"]["sunset"].string
                    
                    print("Sunrise: \(sunriseTime)")
                    print("Sunset: \(sunsetTime)")

                    self.sunRise.text = sunriseTime
                    self.sunSet.text = sunsetTime
                    
                    
                    
                    if (WCSession.default.isReachable) {
                           // construct the message you want to send
                           // the message is in dictionary
                        let message = ["SunRise": self.sunRise.text,"SunSet": self.sunSet.text, "city": self.search.text]
                          // send the message to the watch
                           WCSession.default.sendMessage(message, replyHandler: nil)
                    }
            }

        }
    }
}

